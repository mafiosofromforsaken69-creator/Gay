# Chefes de Ferro - gerar o APK
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta.
2. Aba Actions > Build APK > Run workflow (roda sozinho a cada envio).
3. Ao terminar, baixe o artefato chefes-de-ferro-apk (app-debug.apk) e instale no Android.
Editar sprites: coloque os PNGs em www/sprites/ (veja LEIA-ME.txt dessa pasta) e envie de novo.
Local: npm install, npx cap add android, npx cap sync, npx cap open android.
